#!/bin/bash
# Módulo de protección LexGPT: restauración y chequeo
while true; do
  echo '[✔] Vigilante activo — sistema estable.'
  sleep 300
done